Install with `python setup.py install`

Requirements in `requirements.txt`

To run an experiment, run `python online.py`, changing the hyperparameters in the file.

To run a grid of experiments, run `python grid_online.py` (adapted for a SLURM cluster)

To analyse a grid of experiment, run `python analyse_online.py`